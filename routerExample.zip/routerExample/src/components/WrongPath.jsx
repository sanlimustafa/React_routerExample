import React from 'react'

function WrongPath() {
  return (
    <div>
      404 Hatası
    </div>
  )
}

export default WrongPath

import React from 'react'

function AboutUs() {
  return (
    <div>
      Lorem ipsum dolor sit amet consectetur adipisicing elit.
       Provident ipsam deserunt eaque a nisi at eveniet reprehenderit impedit debitis
        libero temporibus molestias assumenda ea aperiam, delectus amet sunt recusandae
         mollitia!
         Lorem ipsum dolor sit amet consectetur adipisicing elit.
       Provident ipsam deserunt eaque a nisi at eveniet reprehenderit impedit debitis
        libero temporibus molestias assumenda ea aperiam, delectus amet sunt recusandae
         mollitia!
         Lorem ipsum dolor sit amet consectetur adipisicing elit.
       Provident ipsam deserunt eaque a nisi at eveniet reprehenderit impedit debitis
        libero temporibus molestias assumenda ea aperiam, delectus amet sunt recusandae
         mollitia!
         Lorem ipsum dolor sit amet consectetur adipisicing elit.
       Provident ipsam deserunt eaque a nisi at eveniet reprehenderit impedit debitis
        libero temporibus molestias assumenda ea aperiam, delectus amet sunt recusandae
         mollitia!
    </div>
  )
}

export default AboutUs
